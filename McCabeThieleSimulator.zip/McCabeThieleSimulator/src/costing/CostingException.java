package costing;

@SuppressWarnings("serial")
public class CostingException extends Exception {
	public CostingException(String msg) {
		super(msg);
	}
}
