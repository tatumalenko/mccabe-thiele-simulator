package process.unitoperation;

import jexcel.excelextractor.*;

public class SieveTray extends Tray {

	//--------------------------------------------------
	//	CONSTRUCTOR(S)
	//--------------------------------------------------
	public SieveTray() { }// end of empty constructor

	public SieveTray(ExcelExtractor ee) {
		super(ee);
	}// end of overloaded constructor

}// end of SieveTray class
